#!/usr/bin/env python

"""
このファイルは ``python -m tablelinker`` で呼び出された場合に実行されます。
"""

from tablelinker.cli import main

if __name__ == '__main__':
    main()
